const ffmpeg = require('fluent-ffmpeg');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { createWriteStream } = require('fs');
const { YudzCdnV2 } = require("./UploaderCdn.js");

async function downloadFile(url, outputPath) {
    try {
        const response = await axios({
            url,
            method: 'GET',
            responseType: 'stream',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
                'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
                'Connection': 'keep-alive',
                'Referer': url
            }
        });
        const writer = createWriteStream(outputPath);
        response.data.pipe(writer);
        return new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });
    } catch (err) {
        throw new Error(`Gagal download file dari ${url}: ${err.message}`);
    }
}

function getAudioDuration(filePath) {
    return new Promise((resolve, reject) => {
        ffmpeg.ffprobe(filePath, (err, metadata) => {
            if (err) return reject(err);
            resolve(metadata.format.duration);
        });
    });
}

async function convertToVideo(urlFotos, urlAudio) {
    const tmpDir = path.join(__dirname, '../tmp');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
    const audioPath = path.join(tmpDir, 'downloaded_audio.mp3');
    const imagePath = path.join(tmpDir, 'first_image.jpg');
    const outputVideo = path.join(tmpDir, 'outputVideo.mp4');

    try {
        // ambil hanya foto pertama
        const firstFoto = urlFotos[0];
        if (!firstFoto) throw new Error("Array foto kosong, tidak ada gambar pertama.");
        await downloadFile(firstFoto, imagePath);

        await downloadFile(urlAudio, audioPath);

        return new Promise((resolve, reject) => {
            ffmpeg()
                .input(imagePath)
                .loop() // bikin gambar ditahan sepanjang audio
                .input(audioPath)
                .outputOptions([
                    '-c:v libx264',
                    '-pix_fmt yuv420p',
                    '-r 30',
                    '-c:a aac',
                    '-shortest' // stop sesuai durasi audio
                ])
                .on('start', (cmd) => {
                    console.log('FFmpeg mulai dengan command:', cmd);
                })
                .on('end', async () => {
                    try {
                        const response = await YudzCdnV2(outputVideo);
                        [imagePath, audioPath, outputVideo].forEach(f => {
                            if (fs.existsSync(f)) fs.unlinkSync(f);
                        });
                        if (fs.existsSync(tmpDir)) {
                            fs.rmSync(tmpDir, { recursive: true, force: true });
                        }
                        return resolve({
                            status: 200,
                            author: "Yudzxml",
                            data: response.result.url
                        });
                    } catch (uploadError) {
                        return reject(uploadError);
                    }
                })
                .on('error', (err) => {
                    return reject(new Error(`FFmpeg error: ${err.message}`));
                })
                .save(outputVideo);
        });
    } catch (error) {
        throw new Error(`convertToVideo gagal: ${error.message}`);
    }
}

module.exports = { convertToVideo };