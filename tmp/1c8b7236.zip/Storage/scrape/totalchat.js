const fs = require('fs').promises;
const path = require('path');

const path_totalchat = path.join(__dirname, '../db/totalchat.json');
const path_backup = path.join(__dirname, '../db/totalchat.bak.json');

async function ensureFileExists(filePath) {
  try {
    await fs.access(filePath);
  } catch (err) {
    if (err.code === 'ENOENT') {
      const dir = path.dirname(filePath);
      await fs.mkdir(dir, { recursive: true });
      await fs.writeFile(filePath, '{}', 'utf8');
    } else {
      throw err;
    }
  }
}

async function readChatData() {
  try {
    await ensureFileExists(path_totalchat);
    const dataRaw = await fs.readFile(path_totalchat, 'utf8');
    try {
      return JSON.parse(dataRaw);
    } catch (err) {
      await ensureFileExists(path_backup);
      const backupRaw = await fs.readFile(path_backup, 'utf8');
      try {
        await fs.writeFile(path_totalchat, backupRaw, 'utf8');
        return JSON.parse(backupRaw);
      } catch (e) {
        return {};
      }
    }
  } catch {
    return {};
  }
}

async function saveChatData(data) {
  try {
    await ensureFileExists(path_totalchat);
    await ensureFileExists(path_backup);
    const currentData = await fs.readFile(path_totalchat, 'utf8');
    await fs.writeFile(path_backup, currentData, 'utf8');
    await fs.writeFile(path_totalchat, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    throw err;
  }
}

async function incrementChatCount(groupId, userNumber) {
  const chatData = await readChatData();
  if (!chatData[groupId]) chatData[groupId] = {};
  if (!chatData[groupId][userNumber]) chatData[groupId][userNumber] = 0;
  chatData[groupId][userNumber] += 1;
  await saveChatData(chatData);
}

async function getChatCountsByGroup(groupId) {
  const chatData = await readChatData();
  if (chatData[groupId]) {
    const chatCounts = Object.entries(chatData[groupId])
      .map(([userNumber, count]) => ({ userNumber, count }))
      .sort((a, b) => b.count - a.count);
    let result = '';
    chatCounts.forEach(({ userNumber, count }) => {
      if (userNumber && userNumber.trim() !== '') {
        result += `⭔ @${userNumber.split('@')[0]} ${count} Chat\n`;
      }
    });
    return result;
  } else {
    return `No data found for group ${groupId}.`;
  }
}

async function getAllNumbersByGroup(groupId) {
  const chatData = await readChatData();
  if (chatData[groupId]) {
    return Object.keys(chatData[groupId]);
  } else {
    return [];
  }
}

module.exports = {
  incrementChatCount,
  getChatCountsByGroup,
  getAllNumbersByGroup,
  readChatData,
  saveChatData,
};