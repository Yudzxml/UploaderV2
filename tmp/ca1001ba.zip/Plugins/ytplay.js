const yts = require('yt-search');
const fetch = require('node-fetch');

module.exports = {
    command: ['play2'],
    prefix: true,
    operate: async (context) => {
        const { m, reply, isRegistered, isBan, text, Yudzxml, config, mess, loading, MinLimit } = context;

        if (!isRegistered) return reply(mess.register);
        if (isBan) return reply(mess.ban);
        if (!text) return reply('Silakan masukkan judul lagu yang ingin dicari.');

        if (!MinLimit(m.sender)) return;

        await loading();
        try {
            let search = await yts(text);
            let firstVideo = search.all[0];

            if (!firstVideo) {
                return reply('Tidak ada video yang ditemukan.');
            }

            let response = await fetch(`https://api-yudzxml.vercel.app/api/ytdl?url=${firstVideo.url}&format=mp3`);
            let memek = await response.json();

            if (memek.error) {
                return reply(`Error: ${memek.error}`);
            }

            let hasil = memek.result;

            if (!hasil || !hasil.download) {
                return reply('Gagal mendapatkan link download.');
            }

            await Yudzxml.sendMessage(m.chat, {
                audio: {
                    url: hasil.download
                },
                mimetype: 'audio/mpeg',
                contextInfo: {
                    externalAdReply: {
                        showAdAttribution: true,
                        title: firstVideo.title || 'Untitled',
                        body: `${config.botname}`,
                        sourceUrl: firstVideo.url,
                        thumbnailUrl: firstVideo.thumbnail || 'https://example.com/default_thumbnail.jpg',
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m });
        } catch (e) {
            console.log(e);
            return reply(mess.error);
        }
    }
};