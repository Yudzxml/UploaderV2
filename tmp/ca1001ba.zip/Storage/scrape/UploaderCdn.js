const axios = require('axios');
const fs = require('fs')
const FormData = require('form-data');
// UPLOAD TO API
async function uploadFileToApi(filePath, expired) {
    try {
        const form = new FormData();
        form.append('expired', expired); // 1minute, 1hour, 1day, 1month and 6months
        form.append('file', fs.createReadStream(filePath));
        
        const response = await axios.put(
            "https://autoresbot.com/tmp-files/upload",
            form,
            {
                headers: {
                    ...form.getHeaders(),
                    'Referer': 'https://autoresbot.com/',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36 Edg/126.0.0.0'
                }
            }
        );
        return response.data;
    } catch (error) {
        return error;
    }
}

async function AutoresbotCdn(filePath) {
    try {
        const form = new FormData();
        form.append('expired', '6months'); // 1minute, 1hour, 1day, 1month and 6months
        form.append('file', fs.createReadStream(filePath));
        
        const response = await axios.put(
            "https://autoresbot.com/tmp-files/upload",
            form,
            {
                headers: {
                    ...form.getHeaders(),
                    'Referer': 'https://autoresbot.com/',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36 Edg/126.0.0.0'
                }
            }
        );
        return {
        success: true,
        author: 'Yudzxml',
        message: 'File uploaded successfully',
        result: {
        success: true,
        creator: 'Autoresbot',
        url: response.data.fileUrl,
        expired: response.data.expired
        },
      };
    } catch (error) {
        return error;
    }
}

async function ShannzCdn(path) {
  const form = new FormData();

  const fileStream = fs.createReadStream(path);
  form.append("file", fileStream);

  try {
    const response = await axios.post("https://api.shannz.work.gd/server/upload", form, {
      headers: {
        ...form.getHeaders(), 
      },
    });

    return response.data
  } catch (error) {
    return error.message
  }
}

async function YudzCdn(path) {
  const form = new FormData();

  const fileStream = fs.createReadStream(path);
  form.append("file", fileStream);

  try {
    const response = await axios.post(`https://8030.us.kg/api/upload.php`, form, {
      headers: {
        ...form.getHeaders(), 
      },
    });

    return response.data
  } catch(error) {
    return error.message
  }
} 

function generateRandomFileName(baseName, extension) {
    const randomNumber = Math.floor(Math.random() * 1000) + 1;
    return `${baseName}${randomNumber}.${extension}`;
}

async function uploadToGitHub(filePath) {
    const githubToken = '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';
    const originalFileName = filePath.split('/').pop();
    const extension = originalFileName.split('.').pop();
    const baseName = 'Yudzxml';
    const randomNumber = Math.floor(Math.random() * 1000) + 1;
    const fileName = `${baseName}${randomNumber}.${extension}`;

    const fileContent = fs.readFileSync(filePath, { encoding: 'base64' });
    const repoOwner = 'Yudzxml';
    const repoName = 'Uploader';
    const branch = 'main';
    const url = `https://api.github.com/repos/${repoOwner}/${repoName}/contents/${fileName}`;

    try {
        const getResponse = await axios.get(url, {
            headers: {
                'Authorization': `token ${githubToken}`,
                'Accept': 'application/vnd.github.v3+json',
            },
        });

        const sha = getResponse.data.sha;
        await axios.put(url, {
            message: 'Upload file',
            content: fileContent,
            sha: sha,
        }, {
            headers: {
                'Authorization': `token ${githubToken}`,
                'Accept': 'application/vnd.github.v3+json',
            },
        });

    } catch (error) {
        if (error.response && error.response.status === 404) {
            await axios.put(url, {
                message: 'Upload file',
                content: fileContent,
            }, {
                headers: {
                    'Authorization': `token ${githubToken}`,
                    'Accept': 'application/vnd.github.v3+json',
                },
            });
        } else {
            console.error('Error uploading file to GitHub:', error.response ? error.response.data : error.message);
            throw new Error('Upload to GitHub failed');
        }
    }
    return {
        success: true,
        author: repoOwner,
        message: 'File uploaded successfully',
        result: {
        url: `https://raw.githubusercontent.com/${repoOwner}/${repoName}/${branch}/${fileName}`,
        }
    };
}

async function catbox(path) {
    const data = new FormData();
    data.append('reqtype', 'fileupload');
    data.append('userhash', '');
    data.append('fileToUpload', fs.createReadStream(path));

    const config = {
        method: 'POST',
        url: 'https://catbox.moe/user/api.php',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
            'Accept': 'application/json',
            'accept-language': 'id-ID',
            'referer': 'https://catbox.moe/',
            'cache-control': 'no-cache',
            'x-requested-with': 'XMLHttpRequest',
            ...data.getHeaders()
        },
        data: data
    };

    try {
        const api = await axios.request(config);
        return {
        success: true,
        author: 'Yudzxml',
        result: {
        message: 'File Uploaded Successfully',
        url: api.data,
        }
    }
    } catch (error) {
        console.error('Error uploading file:', error);
        throw error; 
    }
}

const imghippo = async (filePath) => {
    const API_KEY = '25a07bd9468433c32edea7db5ec59a72';
    const form = new FormData();
    form.append('api_key', API_KEY);
    form.append('file', fs.createReadStream(filePath));

    try {
        const response = await axios.post('https://api.imghippo.com/v1/upload', form, {
            headers: {
                ...form.getHeaders(),
            },
        });
        return { 
            status: 'true',
            author: 'Yudzxml',
            result: response.data.data
        };
    } catch (error) {
        console.error('Error uploading file:', error.response ? error.response.data : error.message);
    }
};

async function supaCdn(filePath) {
    const url = 'https://i.supa.codes/api/upload';
    const form = new FormData();

    form.append('file', fs.createReadStream(filePath));

    try {
        const response = await axios.post(url, form, {
            headers: {
                ...form.getHeaders()
            }
        });

        return {
            status: 200,
            author: "Yudzxml",
            result: { 
            url: response.data.link,
            deletionURL: response.data.delete,
            errorMessage: response.data.message
            }
        };
    } catch (error) {
        if (error.response) {
            return {
                errorMessage: error.response.data.message || 'An error occurred during upload.'
            };
        } else if (error.request) {
            return {
                errorMessage: 'No response received from the server.'
            };
        } else {
            return {
                errorMessage: error.message
            };
        }
    }
}

module.exports = {
  uploadFileToApi,
  ShannzCdn,
  YudzCdn,
  catbox,
  uploadToGitHub,
  AutoresbotCdn,
  supaCdn,
  imghippo
};

