/**
YUDZ MD - V10
WHATSAPP : 6283872031397
CREATE : 1 OKTOBER 2024
LAST UPDATE : 24 MEI 2025
**/

const fs = require('fs')
const chalk = require('chalk')
const moment = require('moment-timezone')
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')	
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const jammenit = moment().tz('Asia/Jakarta').format('HH:mm');


const config = {
  pairingCode: true,
  superowner: '6283872031397',
  region: 'Indonesia',
  ownername: '❃ ʏᴜᴅᴢ - ᴍᴜʟᴛɪᴅᴇᴠɪᴄᴇ',
  namestore: 'YUDZXML STORE 77',
  email: 'yudaaryaardhana1122@gmail.com',
  botname: 'X7BOTZ - MD V10',
  packname: '❃ ʏᴜᴅᴢ - ᴍᴜʟᴛɪᴅᴇᴠɪᴄᴇ',
  author: `Date: ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}\nTelegram: @Yudzxzy\nSticker: By Yudzxml`,
  themeemoji: '🍁',
  urldb: '',// KOSONGIN
  saluran: 'https://whatsapp.com/channel/0029VaQfuS74dTnEv0b6hA1g',
  grup: 'https://chat.whatsapp.com/BiY2EOldsEK0xXzxJP1Lm9',
  idch: '120363263460724112@newsletter',
  prefix_custom: ['/','!','.','#','&'],
  resetclaim: 720,
  resetlimit: 1440,
  sleep_game: 60000,
  MoneyMenangGame: 20,
  ratelimiter: 3,
  typeWelcome: 1,
  waktubackup: 1440,
  waktureboot: 360,
  botDestination: 'group',
  icon_on: '🟢',
  icon_off: '🟡',

// APIKEYS
apikey: {
  auto  : 'https://api.autoresbot.com',
  res   : 'd79b5492b3e840d089939fcf',
  res2  : 'APIKEY_MIKUBOT',
  beta  : 'https://api.betabotz.eu.org',
  botz  : 'APIKEY_YUDZXML'
}, 

// PANEL PTREODATYL
panel: { 
  plta: '',
  pltc: '',
  domain: ''
},

// SUBDOMAIN CF
subdomain: {
  domain: '',
  zone: '',
  token: '',
  domain2: '',
  zone2: '',
  token2: '',
  domain3: '',
  zone3: '',
  token3: '',
  domain4: '',
  zone4: '',
  token4: '',
  domain5: '',
  zone5: '',
  token5: ''
},

// DIGITAL OCEAN
do: {
  api_token: ''
},

// MULTIMEDIA ALLMENU
thumbnail: {
  qris: [
'https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml524.jpg'
],
  allmenu: [
'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/VID-20250614-WA0077.mp4'
],
  imagereply: [
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/2fc1c35e.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/59edb6a3.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/4803fcd1.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/43d2387f.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/03581e59.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/e61e1a6b.jpg"
],
  imagemenu: [
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/7faa96e3.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/d65e752e.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/f8f8d36a.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/b876b720.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/d8a8e7af.jpg",
"https://i.supa.codes/VAbwQA"
],
  audio: [
"https://files.catbox.moe/zwn8tr.mp3",
"https://files.catbox.moe/7evq63.mp3",
"https://files.catbox.moe/kpggzt.mp3",
"https://files.catbox.moe/aot9pk.mp3",
"https://autoresbot.com/tmp_files/ade17287-b1ab-4ca8-95f6-6ffe9341e13c.mp3",
"https://files.catbox.moe/uitc67.mp3",
"https://files.catbox.moe/t5x904.mp3"
 ]
 }
};

module.exports = config;

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(`${chalk.greenBright.bold('[ '+jammenit+' ]')} ${chalk.greenBright.bold(`UPDATE FILE ${__filename}`)}`)
    delete require.cache[file]
    require(file)
})
