const ffmpeg = require('fluent-ffmpeg');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const { createWriteStream } = require('fs');

async function uploadFileToApi(filePath, expired) {
    try {
        const form = new FormData();
        form.append('expired', expired);
        form.append('file', fs.createReadStream(filePath));
        
        const response = await axios.put(
            "https://autoresbot.com/tmp-files/upload",
            form,
            {
                headers: {
                    ...form.getHeaders(),
                    'Referer': 'https://autoresbot.com/',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36 Edg/126.0.0.0'
                }
            }
        );
        return response.data;
    } catch (error) {
        console.error('Error uploading file:', error.response ? error.response.data : error.message);
        return null;
    }
}

async function downloadFile(url, outputPath) {
    const response = await axios({
        url,
        method: 'GET',
        responseType: 'stream',
    });
    const writer = createWriteStream(outputPath);
    response.data.pipe(writer);
    return new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
    });
}

async function convertToVideo(urlFoto, urlAudio) {
    const tmpDir = path.join(__dirname, 'tmp');
    const imagePath = path.join(tmpDir, 'downloaded_image.jpg');
    const audioPath = path.join(tmpDir, 'downloaded_audio.mp3');
    const outputVideo = path.join(tmpDir, 'outputVideo.mp4');

    try {
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir);
        }
        await downloadFile(urlFoto, imagePath);
        await downloadFile(urlAudio, audioPath);

        return new Promise((resolve, reject) => {
            ffmpeg()
                .input(imagePath)
                .input(audioPath)
                .outputOptions('-c:v libx264')
                .outputOptions('-pix_fmt yuv420p')
                .outputOptions('-r 30')
                .outputOptions('-vf scale=640:480')
                .outputOptions('-c:a aac')
                .on('end', async () => {
                    try {
                        const response = await uploadFileToApi(outputVideo, '1hour');
                        fs.unlinkSync(imagePath);
                        fs.unlinkSync(audioPath);
                        fs.unlinkSync(outputVideo);
                        fs.rmdirSync(tmpDir);
                        return resolve({
                            status: 200,
                            author: "Yudzxml",
                            data: response.fileUrl
                        });
                    } catch (uploadError) {
                        reject(uploadError);
                    }
                })
                .on('error', (err) => {
                    reject(err);
                })
                .save(outputVideo);
        });
    } catch (error) {
        console.error('Error:', error);
    }
}

module.exports = { convertToVideo };