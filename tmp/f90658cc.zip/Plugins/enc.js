const fs = require('fs');
const path = require('path');
const JavaScriptObfuscator = require('javascript-obfuscator');

module.exports = {
  command: ['encskrip', 'obfuscator', 'encrypt', 'enc'],
  operate: async (context) => {
    const {
      m, text, reply, isDocument, quoted, isRegistered,
      MinLimit, loading, Yudzxml, mess
    } = context;

    try {
      console.log('[ENC] Mulai proses obfuscate...');
      if (!isRegistered) {
        console.log('[ENC] Gagal - Pengguna belum terdaftar.');
        return reply(mess.register);
      }

      if (!MinLimit(m.sender)) {
        console.log('[ENC] Gagal - Limit habis untuk:', m.sender);
        return;
      }

      if (!text && !m.quoted) {
        console.log('[ENC] Gagal - Tidak ada input teks atau file.');
        return reply('⚠️ Kirim kode sebagai teks atau upload file (.js).');
      }

      await loading();

      const obfuscateCode = (code) => {
        if (!code || typeof code !== 'string' || code.trim().length === 0) {
          console.log('[ENC] Input kosong atau bukan string.');
          return null;
        }

        try {
          const result = JavaScriptObfuscator.obfuscate(code, {
            compact: true,
            controlFlowFlattening: true,
            controlFlowFlatteningThreshold: 0.75,
            deadCodeInjection: true,
            deadCodeInjectionThreshold: 0.4,
            stringArray: true,
            stringArrayEncoding: ['base64'],
            selfDefending: true,
            transformObjectKeys: true,
            renameGlobals: false
          });

          const finalCode = result.getObfuscatedCode?.();
          if (!finalCode || finalCode.trim().length === 0) {
            console.log('[ENC] Hasil obfuscate kosong!');
            return null;
          }

          return finalCode;
        } catch (err) {
          console.error('[ENC] Error saat obfuscate:', err);
          return null;
        }
      };

      if (m.quoted.mtype == 'documentMessage') {
        console.log('[ENC] Mode file aktif.');

        if (!m.quoted || m.quoted.mtype !== 'documentMessage') {
          console.log('[ENC] Gagal - Tidak ada file yang direply atau bukan dokumen.');
          return reply('⚠️ Harap reply file JavaScript (.js) untuk di-obfuscate.');
        }

        const originalFileName = m.quoted.fileName || 'file.js';
        const safeFileName = originalFileName.endsWith('.js') ? originalFileName : `${originalFileName}.js`;

        console.log('[ENC] Mengunduh file:', safeFileName);

        const tempFilePath = await Yudzxml.downloadAndSaveMediaMessage(m.quoted);
        const buffer = fs.readFileSync(tempFilePath);
        const originalCode = buffer.toString('utf-8');

        if (!originalCode.includes('{') || !originalCode.includes('}')) {
          console.log('[ENC] File kemungkinan bukan JavaScript valid.');
          return reply('⚠️ File tidak terdeteksi sebagai JavaScript valid.');
        }

        const obfuscatedCode = obfuscateCode(originalCode);
        if (!obfuscatedCode) {
          console.log('[ENC] Gagal obfuscate isi file.');
          return reply('❌ Gagal meng-obfuscate file. Periksa kembali isi file JavaScript kamu.');
        }

        const obfuscatedBuffer = Buffer.from(obfuscatedCode, 'utf-8');

        console.log('[ENC] File berhasil diobfuscate, mengirim...');
        await reply(`✅ File berhasil di-obfuscate: *enc_${safeFileName}*`);
        await Yudzxml.sendMessage(m.chat, {
          document: obfuscatedBuffer,
          fileName: `enc_${safeFileName}`,
          mimetype: 'application/javascript',
          caption: '🤖 Berikut hasil obfuscate dari file kamu.'
        }, { quoted: m });

        // Optional: hapus file temp
        fs.unlinkSync(tempFilePath);

      } else {
        console.log('[ENC] Mode teks aktif.');

        const inputCode = text.trim();
        console.log('[ENC] Input code:', inputCode.substring(0, 100) + '...');

        const obfuscatedCode = obfuscateCode(inputCode);
        if (!obfuscatedCode) {
          console.log('[ENC] Gagal obfuscate input teks.');
          return reply('❌ Gagal meng-obfuscate kode. Pastikan input kamu adalah JavaScript yang valid.');
        }

        if (obfuscatedCode.length < 4000) {
          console.log('[ENC] Kirim sebagai teks.');
          await reply(`✅ Berikut hasil obfuscate:\n\n\`\`\`javascript\n${obfuscatedCode}\n\`\`\``);
        } else {
          const fileName = 'enc_text.js';
          const obfuscatedBuffer = Buffer.from(obfuscatedCode, 'utf-8');

          console.log('[ENC] Kode terlalu panjang, kirim sebagai file.');
          await reply(`✅ Kode terlalu panjang, dikirim sebagai file: *${fileName}*`);
          await Yudzxml.sendMessage(m.chat, {
            document: obfuscatedBuffer,
            fileName,
            mimetype: 'application/javascript',
            caption: '🤖 Ini hasil obfuscate dari input teks kamu.'
          }, { quoted: m });
        }
      }

      console.log('[ENC] Selesai ✅');

    } catch (err) {
      console.error('[PLUGIN: obfuscate] ERROR FATAL:', err);
      reply('❌ Terjadi kesalahan internal saat proses obfuscate.');
    }
  }
};