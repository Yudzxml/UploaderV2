/**
CREATOR: YUDZXML STORE 77
WHATSAPP: 084872031797
CREATE: MIN, 27 JUL 2025
**/

const yts = require('../Storage/scrape/yt-search');
const fetch = require('node-fetch');
const configSetting = require('../settings');
const configMessage = require('../message');

const config = {
  ...configSetting,
  ...configMessage
};

module.exports = {
  command: ['yotubemp3', 'ytmp3', 'youtubemp3', 'play', 'putar', 'ytmusic', 'lagu', 'musik'],
  operate: async (context) => {
    const { m, example, reply, isRegistered, isBan, text, Yudzxml, mess, loading, MinLimit, config: contextConfig } = context;

    if (!isRegistered) return reply(mess.register);
    if (isBan) return reply(mess.ban);
    if (!text) return reply(example('https://youtube.xxxx atau judul'));
    if (!MinLimit(m.sender)) return;

    await loading();

    try {
      // Cari video pertama
      const search = await yts(text);
      if (!search.all || !Array.isArray(search.all) || search.all.length === 0) {
        return reply('Tidak ada video yang ditemukan.');
      }
      const firstVideo = search.all[0];

      // Fungsi helper untuk download audio
      const downloadAudio = async (url, fallback = false) => {
        const apiUrl = fallback
          ? `https://api-yudzxml.koyeb.app/api/ytdl?url=${encodeURIComponent(url)}&quality=128&format=audio`
          : `https://api-yudzxzy.vercel.app/api/download/ytdl?url=${encodeURIComponent(url)}&format=mp3`;

        const response = await fetch(apiUrl);
        const data = await response.json();
        return fallback ? data.data : data.result;
      };

      // Coba download dari primary API
      let hasil = await downloadAudio(firstVideo.url);
      if (!hasil || (!hasil.download && !hasil.downloadUrl)) {
        // fallback ke API kedua
        hasil = await downloadAudio(firstVideo.url, true);
      }

      if (!hasil || (!hasil.download && !hasil.downloadUrl)) {
        return reply('Gagal mendapatkan link download.');
      }

      const audioUrl = hasil.download || hasil.downloadUrl;

      await Yudzxml.sendMessage(
        m.chat,
        {
          audio: { url: audioUrl },
          mimetype: 'audio/mpeg',
          contextInfo: {
            externalAdReply: {
              showAdAttribution: false,
              title: firstVideo.title || 'Untitled',
              body: contextConfig.botname || 'Bot',
              sourceUrl: firstVideo.url,
              thumbnailUrl: firstVideo.thumbnail || 'https://example.com/default_thumbnail.jpg',
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        },
        { quoted: m }
      );
    } catch (error) {
      console.error(error);
      return reply(mess.error);
    }
  }
};