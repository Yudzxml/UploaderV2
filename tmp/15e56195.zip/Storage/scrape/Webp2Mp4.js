const axios = require('axios');
const cheerio = require('cheerio');

async function Webp2Mp4(urls) {
    try {
        const response = await axios.get(`https://ezgif.com/webp-to-mp4?url=${urls}`);
        const $ = cheerio.load(response.data);
        const formAction = $('form.ajax-form').attr('action');
        const fileName = $('input[name="file"]').val();
        
        const postResponse = await axios.post(formAction, new URLSearchParams({
            file: fileName
        }), {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0',
                'Referer': urls
            }
        });

        const $post = cheerio.load(postResponse.data);
        const videoSrc = $post('p.outfile video source').attr('src');
        const fullVideoUrl = videoSrc && videoSrc.startsWith('//') ? `https:${videoSrc}` : videoSrc;

        return {
          success: true,
          redirectUrl: response.request.res.responseUrl,
          fileName: fileName,
          convertUrl: fullVideoUrl
        };
    } catch (error) {
      return { success: false, message: error.message };
      console.error("Error:", error.response ? error.response.data : error.message);      
    }
}

module.exports = { Webp2Mp4 };