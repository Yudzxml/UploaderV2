const fs = require('fs').promises;
const path = require('path');

const path_totalchat = path.join(__dirname, '../db/totalchat.json');

async function ensureFileExists(filePath) {
  try {
    // Cek apakah file ada
    await fs.access(filePath);
  } catch (err) {
    if (err.code === 'ENOENT') {
      // Buat direktori jika belum ada
      const dir = path.dirname(filePath);
      await fs.mkdir(dir, { recursive: true });

      // Buat file dengan isi '{}' (empty object)
      await fs.writeFile(filePath, '{}', 'utf8');
    } else {
      throw err; // Jika error lain, lemparkan
    }
  }
}

async function readChatData() {
  try {
    await ensureFileExists(path_totalchat);
    const data = await fs.readFile(path_totalchat, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Gagal membaca data chat:', err);
    return {};
  }
}

async function saveChatData(data) {
  try {
    await ensureFileExists(path_totalchat);
    await fs.writeFile(path_totalchat, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error('Gagal menyimpan data chat:', err);
    throw err;
  }
}

async function incrementChatCount(groupId, userNumber) {
  const chatData = await readChatData();
  if (!chatData[groupId]) chatData[groupId] = {};
  if (!chatData[groupId][userNumber]) chatData[groupId][userNumber] = 0;
  chatData[groupId][userNumber] += 1;
  await saveChatData(chatData);
}

async function getChatCountsByGroup(groupId) {
  const chatData = await readChatData();
  if (chatData[groupId]) {
    const chatCounts = Object.entries(chatData[groupId])
      .map(([userNumber, count]) => ({ userNumber, count }))
      .sort((a, b) => b.count - a.count);
    let result = ``;
    chatCounts.forEach(({ userNumber, count }) => {
      if (userNumber && userNumber.trim() !== '') {
        result += `⭔ @${userNumber.split('@')[0]} ${count} Chat\n`;
      }
    });
    return result;
  } else {
    return `No data found for group ${groupId}.`;
  }
}

async function getAllNumbersByGroup(groupId) {
  const chatData = await readChatData();
  if (chatData[groupId]) {
    return Object.keys(chatData[groupId]);
  } else {
    return [];
  }
}

module.exports = {
  incrementChatCount,
  getChatCountsByGroup,
  getAllNumbersByGroup,
  readChatData,
  saveChatData,
};
