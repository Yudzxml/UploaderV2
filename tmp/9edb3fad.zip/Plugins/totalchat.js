const { incrementChatCount,
  getChatCountsByGroup,
  getAllNumbersByGroup } = require('../Storage/scrape/totalchat.js')

module.exports = {
  command: ['totalchat'],
  operate: async (context) => {
    const { m, mess, reply, Yudzxml } = context;

    if (!m.isGroup) return reply(mess.group);
    if (!isAdmins) return reply(mess.userNotAdmin);

    try {
      const groupId = m.chat; 
      const report = await getChatCountsByGroup(groupId);

      const message = `📊 *Laporan Total Chat Grup* 📊\n\n${report}\n\n✨ Terima kasih sudah aktif chat di grup! ✨`;

      const mentions = await getAllNumbersByGroup(groupId);
      await Yudzxml.sendMessage(groupId, { text: message, mentions }, { quoted: m });
    } catch (err) {
      console.error(err);
      await reply('⚠️ Gagal mengambil data total chat.');
    }
  }
};
