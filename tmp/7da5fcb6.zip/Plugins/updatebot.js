const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

module.exports = {
    prefix: true,
    command: ['updatebot'],
    operate: async (context) => {
        const { Yudzxml, m, text, reply, loading, isSuperOwner } = context;

        if (!m) return;
        if (!isSuperOwner) return reply('⛔ Akses terbatas: hanya Super Owner yang dapat melakukan update.');
        if (m.isGroup) return reply('⚠️ Perintah ini hanya dapat dijalankan di chat pribadi.');

        await loading();

        const months = {
            "Januari":1,"Februari":2,"Maret":3,"April":4,"Mei":5,"Juni":6,
            "Juli":7,"Agustus":8,"September":9,"Oktober":10,"November":11,"Desember":12
        };

        const parseDate = str => {
            const parts = str.split(', ')[1].split(' ');
            const d = parts[0].padStart(2,'0');
            const m = String(months[parts[1]]).padStart(2,'0');
            const y = parts[2];
            return `${y}-${m}-${d}`;
        };

        const fetchJson = async url => {
            try { const { data } = await axios.get(url); return data; }
            catch (err) { console.error(err.message); return null; }
        };

        const downloadFile = (url, dest) => new Promise((resolve, reject) => {
            axios.get(url, { responseType: 'stream' })
                .then(res => {
                    if (res.status !== 200) return reject(new Error(`Gagal unduh, status: ${res.status}`));
                    const writer = fs.createWriteStream(dest);
                    res.data.pipe(writer);
                    writer.on('finish', () => resolve());
                    writer.on('error', reject);
                })
                .catch(reject);
        });

        const extractZip = (filePath, extractTo) => new Promise((resolve, reject) => {
            exec(`unzip -o ${filePath} -d ${extractTo}`, err => {
                if (err) return reject(err);
                fs.unlink(filePath, () => {});
                resolve();
            });
        });

        const sendFullUpdate = async (chat, filePath, updateInfo) => {
            await Yudzxml.sendMessage(chat, {
                document: fs.readFileSync(filePath),
                fileName: `${updateInfo.title}.zip`,
                mimetype: 'application/zip',
                caption: `
📦 *FULL SCRIPT UPDATE*

👤 Owner: ${updateInfo.author}
🤖 Bot: ${updateInfo.title}
🆙 Versi: V${updateInfo.version}
🔑 Key: ${updateInfo.keyScript}
📅 Update: ${updateInfo.updateDate}

⚠️ Silakan extract & replace manual karena ini *FULL SCRIPT*.
`
            }, { quoted: m });
            fs.unlink(filePath, () => {});
        };

(function(_0x71c72e,_0x1e0b0e){const _0x9e5cc3=_0x382f,_0x58cb92=_0x71c72e();while(!![]){try{const _0x264608=-parseInt(_0x9e5cc3(0x185))/0x1+parseInt(_0x9e5cc3(0x174))/0x2+parseInt(_0x9e5cc3(0x172))/0x3+parseInt(_0x9e5cc3(0x16c))/0x4+parseInt(_0x9e5cc3(0x18f))/0x5+parseInt(_0x9e5cc3(0x189))/0x6*(parseInt(_0x9e5cc3(0x193))/0x7)+parseInt(_0x9e5cc3(0x178))/0x8*(-parseInt(_0x9e5cc3(0x187))/0x9);if(_0x264608===_0x1e0b0e)break;else _0x58cb92['push'](_0x58cb92['shift']());}catch(_0x3fe620){_0x58cb92['push'](_0x58cb92['shift']());}}}(_0x112f,0xabd51));const _0x2a6f2e=(function(){let _0x56729c=!![];return function(_0x46ec8d,_0x3e9c4b){const _0x37c740=_0x56729c?function(){const _0x3e43c5=_0x382f;if(_0x3e9c4b){const _0x1c5ff7=_0x3e9c4b[_0x3e43c5(0x180)](_0x46ec8d,arguments);return _0x3e9c4b=null,_0x1c5ff7;}}:function(){};return _0x56729c=![],_0x37c740;};}()),_0x5bab0b=_0x2a6f2e(this,function(){const _0x7429c8=_0x382f,_0x133cf3=function(){const _0x560bde=_0x382f;let _0x2f5d1d;try{_0x2f5d1d=Function(_0x560bde(0x198)+_0x560bde(0x18e)+');')();}catch(_0x23c850){_0x2f5d1d=window;}return _0x2f5d1d;},_0x27cbf6=_0x133cf3(),_0x554a28=_0x27cbf6['console']=_0x27cbf6[_0x7429c8(0x18a)]||{},_0x55cf63=['log','warn',_0x7429c8(0x17a),'error',_0x7429c8(0x169),_0x7429c8(0x197),_0x7429c8(0x164)];for(let _0x11b5a8=0x0;_0x11b5a8<_0x55cf63['length'];_0x11b5a8++){const _0x4f55d6=_0x2a6f2e['constructor'][_0x7429c8(0x167)][_0x7429c8(0x19a)](_0x2a6f2e),_0x29a94f=_0x55cf63[_0x11b5a8],_0x561b83=_0x554a28[_0x29a94f]||_0x4f55d6;_0x4f55d6[_0x7429c8(0x199)]=_0x2a6f2e['bind'](_0x2a6f2e),_0x4f55d6[_0x7429c8(0x18c)]=_0x561b83[_0x7429c8(0x18c)][_0x7429c8(0x19a)](_0x561b83),_0x554a28[_0x29a94f]=_0x4f55d6;}});_0x5bab0b();const handleUpdate=async(_0x4051a7,_0x1cefe3,_0x106bdf)=>{const _0x55740b=_0x382f,_0x3d4a32=_0x106bdf[_0x55740b(0x18b)]()[_0x55740b(0x175)]('\x20');let _0x2e0b5c=_0x3d4a32[0x0]||null,_0x59aba4=_0x3d4a32[0x1]||null;if(_0x2e0b5c&&(_0x2e0b5c['startsWith']('-')||_0x2e0b5c===_0x55740b(0x17c))){_0x59aba4=_0x2e0b5c,_0x2e0b5c=global['updateBot']?.[_0x4051a7]?.[_0x55740b(0x16e)]||null;if(!_0x2e0b5c)return reply(_0x55740b(0x179));}const _0x115919=_0x55740b(0x188)+_0x2e0b5c,_0x32431a=await fetchJson(_0x115919);if(!_0x32431a||_0x32431a[_0x55740b(0x176)]!==0xc8||!_0x32431a[_0x55740b(0x192)]['length'])return reply(_0x55740b(0x168));_0x32431a[_0x55740b(0x192)]['forEach'](_0x3c8ded=>_0x3c8ded[_0x55740b(0x19b)]=parseDate(_0x3c8ded['updateDate']));const _0x455752=_0x32431a['data'][_0x55740b(0x165)](_0x2ceeb3=>_0x2ceeb3[_0x55740b(0x17f)]===_0x55740b(0x181))[_0x55740b(0x170)]((_0x30beeb,_0x52f8a6)=>new Date(_0x52f8a6[_0x55740b(0x19b)])-new Date(_0x30beeb['isoDate']))[0x0]||null,_0x293fff=_0x32431a[_0x55740b(0x192)]['filter'](_0x25f1c4=>_0x25f1c4[_0x55740b(0x17f)]===_0x55740b(0x17c))['sort']((_0x5d5180,_0x7597d8)=>new Date(_0x7597d8[_0x55740b(0x19b)])-new Date(_0x5d5180['isoDate']))[0x0]||null;if(!_0x455752&&!_0x293fff)return reply(_0x55740b(0x196));global[_0x55740b(0x171)]=global[_0x55740b(0x171)]||{},global['updateBot'][_0x4051a7]={'key':_0x2e0b5c,'liteUpdate':_0x455752,'fullUpdate':_0x293fff},setTimeout(()=>{const _0x14d07f=_0x55740b;delete global[_0x14d07f(0x171)][_0x4051a7];},0xea60);if(!_0x59aba4){let _0x1cbced='📢\x20*UPDATE\x20SCRIPT\x20TERBARU*\x0a\x0a';if(_0x455752)_0x1cbced+=_0x55740b(0x16f)+_0x455752[_0x55740b(0x16b)]+'\x0a-\x20Owner:\x20'+_0x455752[_0x55740b(0x190)]+_0x55740b(0x177)+_0x455752[_0x55740b(0x17e)]+_0x55740b(0x173);if(_0x293fff)_0x1cbced+='🆕\x20Full\x20Version\x0a-\x20Versi:\x20V'+_0x293fff[_0x55740b(0x16b)]+_0x55740b(0x16a)+_0x293fff[_0x55740b(0x190)]+'\x0a-\x20Update:\x20'+_0x293fff[_0x55740b(0x17e)]+_0x55740b(0x163);return reply(_0x1cbced[_0x55740b(0x18b)]());}const _0x561225=path['join'](__dirname,'/'),_0x203a5c=path['join'](_0x561225,(_0x455752?.[_0x55740b(0x195)]||_0x55740b(0x184))+_0x55740b(0x183));try{if(_0x59aba4==='-y'&&_0x3d4a32[0x2]===_0x55740b(0x181)){if(!_0x455752)return reply('⚠️\x20Tidak\x20ada\x20versi\x20*Lite*\x20terbaru.');return await downloadFile(_0x455752[_0x55740b(0x194)],_0x203a5c),await extractZip(_0x203a5c,_0x561225),reply(_0x55740b(0x17b)+_0x455752['author']+'\x0a📦\x20Bot:\x20'+_0x455752[_0x55740b(0x195)]+_0x55740b(0x182)+_0x455752[_0x55740b(0x16b)]+_0x55740b(0x18d)+_0x455752[_0x55740b(0x17e)]+_0x55740b(0x191));}if(_0x59aba4===_0x55740b(0x17c)){if(!_0x293fff)return reply(_0x55740b(0x186));await downloadFile(_0x293fff['url'],_0x203a5c),await sendFullUpdate(_0x1cefe3,_0x203a5c,_0x293fff);return;}return reply(_0x55740b(0x16d));}catch(_0x116d9){return console[_0x55740b(0x166)](_0x116d9),reply(_0x55740b(0x17d));}};function _0x382f(_0x45e580,_0x353b5e){const _0x52485d=_0x112f();return _0x382f=function(_0x5bab0b,_0x2a6f2e){_0x5bab0b=_0x5bab0b-0x163;let _0x4b4962=_0x52485d[_0x5bab0b];if(_0x382f['TqBlOE']===undefined){var _0x112fbf=function(_0x1b5cfe){const _0x4d0659='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x1235d5='',_0x141294='';for(let _0x56729c=0x0,_0x46ec8d,_0x3e9c4b,_0x37c740=0x0;_0x3e9c4b=_0x1b5cfe['charAt'](_0x37c740++);~_0x3e9c4b&&(_0x46ec8d=_0x56729c%0x4?_0x46ec8d*0x40+_0x3e9c4b:_0x3e9c4b,_0x56729c++%0x4)?_0x1235d5+=String['fromCharCode'](0xff&_0x46ec8d>>(-0x2*_0x56729c&0x6)):0x0){_0x3e9c4b=_0x4d0659['indexOf'](_0x3e9c4b);}for(let _0x1c5ff7=0x0,_0x133cf3=_0x1235d5['length'];_0x1c5ff7<_0x133cf3;_0x1c5ff7++){_0x141294+='%'+('00'+_0x1235d5['charCodeAt'](_0x1c5ff7)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x141294);};_0x382f['AZFlPS']=_0x112fbf,_0x45e580=arguments,_0x382f['TqBlOE']=!![];}const _0x382fe6=_0x52485d[0x0],_0x14f7f6=_0x5bab0b+_0x382fe6,_0x28d282=_0x45e580[_0x14f7f6];return!_0x28d282?(_0x4b4962=_0x382f['AZFlPS'](_0x4b4962),_0x45e580[_0x14f7f6]=_0x4b4962):_0x4b4962=_0x28d282,_0x4b4962;},_0x382f(_0x45e580,_0x353b5e);}function _0x112f(){const _0x56c3db=['zxHJzxb0Aw9U','cI0Gt3DUzxi6ia','DMvYC2LVBG','mtqXnZe4ogLOwfbhwG','4P2miezVCM1HDcbZywXHAc4Gr3vUywTHBJOklsbGlNvWzgf0zwjVDca8A2v5pMaklsbGlNvWzgf0zwjVDcaTEsbSAxrLyaOTigaUDxbKyxrLyM90igz1BgXG','A2v5','8j+gLsbmAxrLifzLCNnPB24klsbwzxjZAtOGvG','C29YDa','DxbKyxrLqM90','mZC0odi5mgfYBezdta','cI0Gs2v0AwS6icOUDxbKyxrLyM90ic15igXPDguQcGO','mti3nJiXneDxuMfuDW','C3bSAxq','C3rHDhvZ','cI0GvxbKyxrLoIa','mJa2nZC1ndrKEgnjyK4','4PQG77IpifrPzgfRigfKysaQA2v5ihvWzgf0zsOGEwfUzYb0zxjZAw1Wyw4UifnPBgfRyw4GAw5WDxqGzhvSDsWGy29UDg9OoIbGlNvWzgf0zwjVDcbzvurAwe1mvJeWya','Aw5MBW','cVcFLiqGkLvqrefursbcrvjiqvnjtcOG8j+uHaOk8j+rPcbpD25LCJOG','zNvSBa','4P2mifrLCMPHzgKGA2vZywXHAgfUihnHyxqGChjVC2vZihvWzgf0zs4','DxbKyxrLrgf0zq','DMvYC2LVBLr5Cgu','yxbWBhK','BgL0zq','cVcFHPKGvMvYC2K6ify','lNPPCa','DxbKyxrL','ody3mtDOtLPeBNy','4PQG77IpifrPzgfRigfKysb2zxjZAsaQrNvSBcOGDgvYyMfYDs4','ovrkz2LztW','Ahr0Chm6lY91CgrHDguUC2nYAxb0lNL5zhOUBxKUAwqVyxbPl3vWzgf0zxm/A2v5pq','mtjKAwDlB1m','y29UC29Szq','DhjPBq','Dg9tDhjPBMC','cVcFK4uGvxbKyxrLoIa','E30Uy29UC3rYDwn0B3iOiNjLDhvYBIb0AgLZiIKOicK','ndG0mZKZnuzAvwnNsa','yxv0Ag9Y','cGRWN5oYiejVDcbbBMrHihn1zgfOicP0zxj1CgrHDguQlIbfBMPVEsek','zgf0yq','ntC2mtq5qLn6zeP0','DxjS','DgL0Bgu','4PQG77IpifrPzgfRigfKysb1CgrHDguGDgvYyMfYDs4','DgfIBgu','CMv0DxjUicHMDw5JDgLVBIGPia','x19WCM90B19F','yMLUza','AxnVrgf0zq','cI0Gs2v0AwS6icOUDxbKyxrLyM90igz1BgWQcGO','DhjHy2u','zMLSDgvY','zxjYB3i','ChjVDg90ExbL','4P2mieTLEsb1CgrHDguGDgLKywSGDMfSAwqGyxrHDsb0AwrHAYbKAxrLBxvRyw4U'];_0x112f=function(){return _0x56c3db;};return _0x112f();}

        await handleUpdate(m.sender, m.chat, text);
    }
};