const { createCanvas, loadImage, registerFont } = require('canvas');
const https = require('https');
const fs = require('fs');
const path = require('path');

const FONT_URL = 'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/039934ed.otf';
const FONT_PATH = path.join(__dirname, 'NewakeFont.otf');

function downloadFont(url, dest) {
  return new Promise((resolve, reject) => {
    if (fs.existsSync(dest)) {
      // Kalau font sudah ada, langsung resolve
      return resolve();
    }
    const file = fs.createWriteStream(dest);
    https.get(url, (res) => {
      if (res.statusCode !== 200) {
        reject(new Error(`Gagal download font, statusCode: ${res.statusCode}`));
      }
      res.pipe(file);
      file.on('finish', () => {
        file.close(resolve);
      });
    }).on('error', (err) => {
      fs.unlink(dest, () => reject(err));
    });
  });
}

async function generateProfileImage(
  data,
  bgPathOrUrl = 'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/4a611741.png',
  profilePicUrl = 'https://example.com/default-profile.png'
) {
  await downloadFont(FONT_URL, FONT_PATH);
  registerFont(FONT_PATH, { family: 'CustomFont' });

  const canvas = createCanvas(800, 1200);
  const ctx = canvas.getContext('2d');

  // Load background
  const bg = await loadImage(bgPathOrUrl);
  ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);

try {
  const profileImage = await loadImage(profilePicUrl);
  const profileSize = 160;
  const profileX = 75;
  const profileY = 233;
  const profileRadius = 20; // Radius sudut, bisa disesuaikan

  ctx.save();

  // Buat rounded rect sebagai clipping region
  ctx.beginPath();
  ctx.roundRect(profileX, profileY, profileSize, profileSize, profileRadius);
  ctx.clip();

  // Gambar foto profil dalam clipping
  ctx.drawImage(profileImage, profileX, profileY, profileSize, profileSize);

  ctx.restore(); // Kembalikan state canvas
} catch (err) {
  console.error('Gagal load foto profil:', err);
}

  // DATA PROFIL
  const baseX = [
    240, // NAMA
    330, // ID
    260, // STATUS
    225, // LIMIT
    225, // ROLE
    235, // LEVEL
    265 // MONEY
    ]
  const positionsY = [
    554, // NAMA
    637, // ID
    722, // STATUS
    808, // LIMIT
    892, // ROLE
    980, // LEVEL
    1066 // MONEY
];

ctx.fillStyle = '#00FFFF';
ctx.font = 'bold 40px "CustomFont"';
ctx.textAlign = 'left';
ctx.shadowColor = 'rgba(0, 255, 255, 0.4)';
ctx.shadowBlur = 8;
ctx.shadowOffsetX = 0;
ctx.shadowOffsetY = 0;
ctx.fillText(data.nama, baseX[0], positionsY[0]);
ctx.fillText(String(data.id), baseX[1], positionsY[1]);
ctx.fillText(data.status, baseX[2], positionsY[2]);
ctx.fillText(String(data.limit), baseX[3], positionsY[3]);
ctx.fillText(String(data.role), baseX[4], positionsY[4]);
ctx.fillText(String(data.level), baseX[5], positionsY[5]);
ctx.fillText(String(data.money), baseX[6], positionsY[6]);
ctx.shadowBlur = 0;

  // Progress bar config
  const progressBarConfig = {
    x: 432,
    y: 273,
    width: 310,
    height: 78,
    radius: 40
  };

  let value = Math.max(0, Math.min(data.level_cache, 100));
  const percent = value / 100;
  const minFillWidth = 50;
  const fillWidth = value === 0 ? 0 : Math.max(progressBarConfig.width * percent, minFillWidth);

  // Background bar
  ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
  ctx.beginPath();
  ctx.roundRect(progressBarConfig.x, progressBarConfig.y, progressBarConfig.width, progressBarConfig.height, progressBarConfig.radius);
  ctx.fill();
  
  const barRadius = Math.min(progressBarConfig.radius, fillWidth / 2);

  // Isi bar
  if (fillWidth > 0) {
    const grad = ctx.createLinearGradient(progressBarConfig.x, progressBarConfig.y, progressBarConfig.x + progressBarConfig.width, progressBarConfig.y);
    grad.addColorStop(0, '#00FFFF');
    grad.addColorStop(1, '#0077FF');

    ctx.fillStyle = grad;
    ctx.shadowColor = '#00FFFF';
    ctx.shadowBlur = 15;
    ctx.beginPath();
    ctx.roundRect(progressBarConfig.x, progressBarConfig.y, fillWidth, progressBarConfig.height, barRadius);
    ctx.fill();
    ctx.shadowBlur = 0;
  }

  // Text progress
  ctx.fillStyle = '#FFFFFF';
  ctx.textAlign = 'center';

  if (value === 0) {
    ctx.font = 'bold 26px "CustomFont"';
    ctx.fillText(`${value} / 100`, progressBarConfig.x + progressBarConfig.width / 2, progressBarConfig.y + progressBarConfig.height - 30);
  } else {
    ctx.font = 'bold 20px "CustomFont"';
    ctx.fillText(`${value} / 100`, progressBarConfig.x + progressBarConfig.width / 2, progressBarConfig.y + progressBarConfig.height - 30);
  }

  return canvas.toBuffer('image/png');
}

module.exports = generateProfileImage;
