const axios = require('axios');
const cheerio = require('cheerio');

// TIKTOK SLIDE HD FUNCTION
async function ttslide(url) {
  try {
    const { data: html } = await axios.get(`https://dlpanda.com/id?url=${url}&token=G7eRpMaa`);
    const $ = cheerio.load(html);
    const images = [];

    $('div.col-md-12 > img').each((_, el) => {
      const src = $(el).attr('src');
      if (src) images.push(src);
    });

    return [{
      creator: 'Yudzxml',
      imgSrc: images
    }];
  } catch (error) {
    console.error('Gagal mengambil slide TikTok:', error.message);
    return [{
      creator: 'Yudzxml',
      imgSrc: [],
      error: true,
      message: error.message
    }];
  }
}

module.exports = { ttslide };