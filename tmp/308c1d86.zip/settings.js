/**
YUDZ MD - V10
WHATSAPP : 6283872031397
CREATE : 1 OKTOBER 2024
LAST UPDATE : 24 MEI 2025
**/

const fs = require('fs')
const chalk = require('chalk')
const moment = require('moment-timezone')
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')	
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const jammenit = moment().tz('Asia/Jakarta').format('HH:mm');


const config = {
  pairingCode: true, // PAIRING CODE MEGUNAKAN NOMOR HP TRUE ( AKTIF ), FALSE ( MATI )
  markOnlineOnConnect: true, // ONLINE 24 JAM KETIKA TERHUBUNG
  superowner: {
    jid: '6283872031397', // NOMOR HP
    lid: '46407608180759' // NOMOR LID DALAM GRUP
  },
  region: 'Indonesia', // NEGARA
  ownername: '❃ ʏᴜᴅᴢ - ᴍᴜʟᴛɪᴅᴇᴠɪᴄᴇ', // NAMA PEMILIK
  namestore: 'YUDZXML STORE 77', // NAMA STORE
  email: 'yudaaryaardhana1122@gmail.com', // EMAIL PEMILIK
  botname: 'X7BOTZ - MD V10', // NAMA BOT
  packname: '❃ ʏᴜᴅᴢ - ᴍᴜʟᴛɪᴅᴇᴠɪᴄᴇ', // PACKNAME STICKER
  author: `Date: ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}\nTelegram: @Yudzxzy\nSticker: By Yudzxml`, // AUTHOR PACK STICKER
  themeemoji: '🍁', 
  urldb: '',// KOSONGIN
  saluran: 'https://whatsapp.com/channel/0029VaQfuS74dTnEv0b6hA1g', // SALURAN WA
  grup: 'https://chat.whatsapp.com/BiY2EOldsEK0xXzxJP1Lm9', // GRUP WA
  idch: '120363263460724112@newsletter', // ID SALURAN
  prefix_custom: ['/','!','.','#','&'], // PERINTAH AWALAN UNTUK BOT
  modeautojpm: 1, // 1 = text only, 2 = text+image, 3 = video+text
  resetclaim: 720, // WAKTU RESET CLAIM LIMIT
  resetlimit: 1440, // WAKTU RESET LIMIT
  sleep_game: 60000, // WAKTU HABIS GAME
  MoneyMenangGame: 20, // WIN DALAM GAME
  ratelimiter: 3, // JEDA CHAT MASUK
  typeWelcome: 1, // WELCOME KETIKA BERGABUNG ( TYPE 1 DAN 2 ( WM OWNER IMAGE ) , TYPE 3 ( TEXT ONLY ), TYPE 4 SAMPAI 7 ( RANDOM IMAGE ))
  waktubackup: 1440, // WAKTU BACKUP
  waktureboot: 360, // WAKTU REBOOT BOT
  botDestination: 'group', // BOT AKTIF DI ( group, private, both ( aktif keduanya ))
  icon_on: '🟢', // BIARIN ATAU GANTI
  icon_off: '🟡', // BIARIN ATAU GANTI

// APIKEYS
apikey: {
  auto  : 'https://api.autoresbot.com',
  res   : 'd79b5492b3e840d089939fcf',
  res2  : 'APIKEY_MIKUBOT',
  beta  : 'https://api.betabotz.eu.org',
  botz  : 'APIKEY_YUDZXML'
}, 

// PANEL PTREODATYL
panel: { 
  plta: '',
  pltc: '',
  domain: ''
},

// SUBDOMAIN CF
subdomain: {
  domain: '',
  zone: '',
  token: '',
  domain2: '',
  zone2: '',
  token2: '',
  domain3: '',
  zone3: '',
  token3: '',
  domain4: '',
  zone4: '',
  token4: '',
  domain5: '',
  zone5: '',
  token5: ''
},

// DIGITAL OCEAN
do: {
  api_token: ''
},

// MULTIMEDIA ALLMENU
thumbnail: {
  qris: [
'https://raw.githubusercontent.com/Yudzxml/Uploader/main/Yudzxml524.jpg'
],
  allmenu: [
'https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/VID-20250614-WA0077.mp4'
],
  imagereply: [
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/2fc1c35e.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/59edb6a3.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/4803fcd1.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/43d2387f.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/03581e59.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/e61e1a6b.jpg"
],
  imagemenu: [
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/7faa96e3.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/d65e752e.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/f8f8d36a.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/82f5752c.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/02a3c164.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/dc5ab274.jpg",
"https://raw.githubusercontent.com/Yudzxml/UploaderV2/main/tmp/171e8189.jpg"
],
  audio: [
"https://files.catbox.moe/zwn8tr.mp3",
"https://files.catbox.moe/7evq63.mp3",
"https://files.catbox.moe/kpggzt.mp3",
"https://files.catbox.moe/aot9pk.mp3",
"https://cdn.ypnk.biz.id/yp/j2mn7235.mp4",
"https://files.catbox.moe/uitc67.mp3",
"https://files.catbox.moe/t5x904.mp3",
"https://cdn.ypnk.biz.id/yp/pu3byyh0.mp4",
"https://cdn.ypnk.biz.id/yp/7gobqge9.mp4",
"https://cdn.ypnk.biz.id/yp/mxn1vz87.mp4"
 ]
 }
};

module.exports = config;

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(`${chalk.greenBright.bold('[ '+jammenit+' ]')} ${chalk.greenBright.bold(`UPDATE FILE ${__filename}`)}`)
    delete require.cache[file]
    require(file)
})
