/**
CREATOR: YUDZXML STORE 77
WHATSAPP: 084872031797
CREATE: MIN, 27 JUL 2025
**/

const axios = require('axios');
const FormData = require('form-data');

module.exports = {
  command: ['encskrip', 'obfuscator', 'encrypt', 'enc'],
  operate: async (context) => {
    const {
      m, text, reply, isDocument, quoted, isRegistered,
      MinLimit, loading, Yudzxml, mess
    } = context;

    const API_URL = 'https://api-yudzxml.koyeb.app/api/enc';

    try {
      console.log('[ENC] Mulai proses obfuscate via API...');

      if (!isRegistered) {
        console.log('[ENC] Gagal - Pengguna belum terdaftar.');
        return reply(mess.register);
      }

      if (!MinLimit(m.sender)) {
        console.log('[ENC] Gagal - Limit habis untuk:', m.sender);
        return;
      }

      if (!text && !(quoted && quoted.mtype === 'documentMessage')) {
        console.log('[ENC] Gagal - Tidak ada input teks atau file.');
        return reply('⚠️ Kirim kode sebagai teks atau upload file (.js).');
      }

      await loading();

      // Mode File
      if (quoted && quoted.mtype === 'documentMessage') {
        console.log('[ENC] Mode file via API.');

        const originalFileName = quoted.fileName || 'file.js';
        const safeFileName = originalFileName.endsWith('.js') ? originalFileName : `${originalFileName}.js`;

        console.log('[ENC] Mengunduh file:', safeFileName);
        const tempFilePath = await Yudzxml.downloadAndSaveMediaMessage(quoted);
        const fileBuffer = require('fs').readFileSync(tempFilePath);

        // Prepare form data
        const form = new FormData();
        form.append('file', fileBuffer, safeFileName);

        console.log('[ENC] Mengirim file ke API...');
        const apiRes = await axios.post(API_URL, form, { headers: form.getHeaders() });
        const obfuscatedCode = apiRes.data?.data?.code;

        if (!obfuscatedCode) {
          console.log('[ENC] API gagal mengembalikan kode obfuscate.');
          return reply('❌ Gagal mendapatkan hasil obfuscate dari API.');
        }

        const obfBuffer = Buffer.from(obfuscatedCode, 'utf-8');
        console.log('[ENC] File berhasil diobfuscate oleh API, mengirim...');
        await reply(`✅ File berhasil di-obfuscate via API: *enc_${safeFileName}*`);
        await Yudzxml.sendMessage(m.chat, {
          document: obfBuffer,
          fileName: `enc_${safeFileName}`,
          mimetype: 'application/javascript',
          caption: '🤖 Berikut hasil obfuscate dari file kamu.'
        }, { quoted: m });

        // Hapus file temporary
        require('fs').unlinkSync(tempFilePath);

      // Mode Teks
      } else {
        console.log('[ENC] Mode teks via API.');
        const inputCode = text.trim();
        console.log('[ENC] Input code:', inputCode.substring(0, 100) + '...');

        console.log('[ENC] Mengirim teks ke API...');
        const apiRes = await axios.get(API_URL, { params: { code: inputCode } });
        const obfuscatedCode = apiRes.data?.data?.code;

        if (!obfuscatedCode) {
          console.log('[ENC] API gagal mengembalikan kode obfuscate.');
          return reply('❌ Gagal mendapatkan hasil obfuscate dari API.');
        }

        if (obfuscatedCode.length < 4000) {
          console.log('[ENC] Kirim hasil sebagai teks.');
          await reply(`✅ Berikut hasil obfuscate (via API):

\`\`\`javascript
${obfuscatedCode}
\`\`\``);
        } else {
          console.log('[ENC] Hasil terlalu panjang, kirim sebagai file.');
          const buffer = Buffer.from(obfuscatedCode, 'utf-8');
          const fileName = 'enc_text.js';
          await reply(`✅ Kode terlalu panjang, dikirim sebagai file: *${fileName}*`);
          await Yudzxml.sendMessage(m.chat, {
            document: buffer,
            fileName,
            mimetype: 'application/javascript',
            caption: '🤖 Ini hasil obfuscate dari input teks kamu.'
          }, { quoted: m });
        }
      }

      console.log('[ENC] Selesai via API ✅');

    } catch (err) {
      console.error('[PLUGIN: obfuscate] ERROR FATAL:', err);
      reply('❌ Terjadi kesalahan internal saat proses obfuscate via API.');
    }
  }
};