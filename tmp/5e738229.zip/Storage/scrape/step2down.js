const axios = require('axios');
const cheerio = require('cheerio');

const step2down = {
    dl: async (link) => {
        try {
            // Mengambil halaman utama untuk mendapatkan token
            const { data: api } = await axios.get('https://steptodown.com/');
            const $ = cheerio.load(api);
            const token = $('#token').val();

            // Memastikan token valid
            if (!token) {
                throw new Error('Token tidak ditemukan. Pastikan halaman tidak berubah.');
            }

            // Mengirim permintaan POST untuk mendapatkan data video
            const { data } = await axios.post('https://steptodown.com/wp-json/aio-dl/video-data/', new URLSearchParams({ url: link, token }), {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'User -Agent': 'Postify/1.0.0'
                }
            });

            return data;
        } catch (error) {
            // Menangani kesalahan dengan lebih baik
            console.error('Error during download:', error.message);
            return { error: error.response?.data || error.message };
        }
    }
}

module.exports = { step2down };