module.exports = {
  command: ['2fa', 'get2fa', 'otp'],
  operate: async (context) => {
    const { m, reply, isRegistered, isBan, text, Yudzxml, mess, loading, MinLimit } = context;

    if (!isRegistered) return reply(mess.register);
    if (isBan) return reply(mess.ban);
    if (!text) return reply('🔑 Silakan masukkan *ID 2FA* yang ingin dicek.\nContoh: `2fa hsbsoahwvjeievw`');

    if (!MinLimit(m.sender)) return;

    await loading();

    try {
      const apiUrl = `https://api.yudzxyz.x-server.my.id/api/2fa-live?id=${encodeURIComponent(text)}`;
      const res = await fetch(apiUrl);
      const data = await res.json();

      if (data.status === 200) {
        const caption = `🔐 *Two Factor Authentication*\n\n` +
                        `👤 *Author:*\n${data.author}\n` +
                        `🆔 *ID:*\n${data.id}\n` +
                        `📌 *Kode Token:*\n${data.token}\n\n` +
                        `⚠️ *Catatan:* Jangan bagikan kode ini kepada siapapun!`;

        await Yudzxml.sendMessage(m.sender, { text: caption }, { quoted: m });
        await reply('TOKEN TELAH DIKIRIM KE DM KAMU')
      } else {
        return reply('❌ ID tidak ditemukan atau API error.');
      }

    } catch (error) {
      console.error('Error pada 2fa command:', error);
      return reply(mess.error);
    }
  }
};