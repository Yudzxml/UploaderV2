/**
CREATOR: YUDZXML STORE 77
WHATSAPP: 084872031797
CREATE: MIN, 27 JUL 2025
**/

const gis = require('g-i-s');

module.exports = {
  command: ['googleimage', 'googleimg', 'searchfoto', 'carifoto', 'imagefinder', 'imagesearch'],
  operate: async (context) => {
    const { 
      text, reply, loading, Yudzxml, m, 
      isRegistered, isBan, MinLimit, mess 
    } = context;

    if (!isRegistered) {
      await reply(mess.register);
      return;
    }
    if (isBan) {
      await reply(mess.ban);
      return;
    }
    if (!MinLimit(m.sender)) return;
    if (!text) {
      await reply('Usage: <keyword>');
      return;
    }

    await loading();

    try {
      gis(text, async (error, results) => {
        if (error) {
          console.error(error);
          await reply(mess.error);
          return;
        }
        if (!results || results.length === 0) {
          await reply('❌ Gambar tidak ditemukan untuk kata kunci tersebut.');
          return;
        }

        let pickedImages = [];
        while (pickedImages.length < 5 && pickedImages.length < results.length) {
          let img = results[Math.floor(Math.random() * results.length)];
          if (!pickedImages.includes(img)) pickedImages.push(img);
        }

        for (const img of pickedImages) {
          await Yudzxml.sendMessage(m.chat, { image: { url: img.url }, caption: mess.success }, { quoted: m });
        }
      });
    } catch (error) {
      console.error(error);
      await reply(mess.error);
    }
  }
};