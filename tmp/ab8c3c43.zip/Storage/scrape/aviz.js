    const axios = require('axios');
    const cheerio = require('cheerio');
// wm avz
    async function aviz(query) {
        const searchUrl = `https://www.inews.id/find?q=${encodeURIComponent(query)}`;
        try {
            const { data } = await axios.get(searchUrl);
            const $ = cheerio.load(data);
            const results = [];
// wm avz
            $('article.cardArticle').each((i, element) => {
                const title = $(element).find('h3.cardTitle').text().trim();
                const url = $(element).find('a').attr('href');
                const imgUrl = $(element).find('img.thumbCard').attr('src');
                const date = $(element).find('div.postTime').text().trim();
// wm avz
                if (title && url && imgUrl && date) {
                    results.push({ title, url, imgUrl, date });
                }
            });
// wm avz
            return results;
        } catch (error) {
            console.error("Error:", error);
            return [];
        }
    }
module.exports = { aviz };