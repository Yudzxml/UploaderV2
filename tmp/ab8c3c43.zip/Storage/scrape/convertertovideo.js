const ffmpeg = require('fluent-ffmpeg');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { createWriteStream } = require('fs');
const { YudzCdnV2 } = require("./UploaderCdn.js");

async function downloadFile(url, outputPath) {
    try {
        const response = await axios({
            url,
            method: 'GET',
            responseType: 'stream',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Connection': 'keep-alive',
                'Referer': url,
                'Upgrade-Insecure-Requests': '1',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'none',
                'Sec-Fetch-User': '?1'
            }
        });
        const writer = createWriteStream(outputPath);
        response.data.pipe(writer);
        return new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });
    } catch (err) {
        throw new Error(`Gagal download file dari ${url}: ${err.message}`);
    }
}

function getAudioDuration(filePath) {
    return new Promise((resolve, reject) => {
        ffmpeg.ffprobe(filePath, (err, metadata) => {
            if (err) return reject(err);
            resolve(metadata.format.duration);
        });
    });
}

async function convertToVideo(urlFotos, urlAudio) {
    const tmpDir = path.join(__dirname, '../tmp');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
    const audioPath = path.join(tmpDir, 'downloaded_audio.mp3');
    const outputVideo = path.join(tmpDir, 'outputVideo.mp4');

    try {
        const imagePaths = [];
        let idx = 0;
        for (const foto of urlFotos) {
            const imgPath = path.join(tmpDir, `slide_${idx++}.jpg`);
            await downloadFile(foto, imgPath);
            imagePaths.push(imgPath);
        }

        await downloadFile(urlAudio, audioPath);

        const audioDuration = await getAudioDuration(audioPath);
        const slideDuration = audioDuration / imagePaths.length;

        const listPath = path.join(tmpDir, 'images.txt');
        const listContent = imagePaths
            .map(p => `file '${p.replace(/\\/g, '/')}'\nduration ${slideDuration}`)
            .join('\n');
        fs.writeFileSync(listPath, listContent);

        return new Promise((resolve, reject) => {
            ffmpeg()
                .input(listPath)
                .inputOptions(['-f concat', '-safe 0'])
                .input(audioPath)
                .outputOptions([
                    '-c:v libx264',
                    '-pix_fmt yuv420p',
                    '-r 30',
                    '-vf scale=640:480',
                    '-c:a aac'
                ])
                .on('start', (cmd) => {
                    console.log('FFmpeg mulai dengan command:', cmd);
                })
                .on('end', async () => {
                    try {
                        const response = await YudzCdnV2(outputVideo);
                        [...imagePaths, audioPath, outputVideo, listPath].forEach(f => {
                            if (fs.existsSync(f)) fs.unlinkSync(f);
                        });
                        if (fs.existsSync(tmpDir)) {
                            fs.rmSync(tmpDir, { recursive: true, force: true });
                        }
                        return resolve({
                            status: 200,
                            author: "Yudzxml",
                            data: response.result.url
                        });
                    } catch (uploadError) {
                        return reject(uploadError);
                    }
                })
                .on('error', (err) => {
                    return reject(new Error(`FFmpeg error: ${err.message}`));
                })
                .save(outputVideo);
        });
    } catch (error) {
        throw new Error(`convertToVideo gagal: ${error.message}`);
    }
}

module.exports = { convertToVideo };