// VARIABLE yg bisa di pakai
/*
{USER}
{WAKTU}
{TANGGAL}
{USERTAG}
{UCAPAN} 
{GRUBNAME}

*/

/**
YUDZ MD - V3
WHATSAPP : 6283872031397
CREATE : 1 OKTOBER 2024
LAST UPDATE : 19 NOVEMBER 2024
**/

// TEMPLATE VERSI 1
/* 
const awalanItem = '» ';
const template_list = `{UCAPAN} {USERTAG}

📝 {GRUBNAME}
⏳ {WAKTU} WIB
📆 {TANGGAL}

*⬇️ List Menu ⬇️*

{LIST_ITEMS}

Untuk Melihat List menu
Ketik *teks* di atas`;
*/





// TEMPLATE VERSI 2
const awalanItem = '╠❥ ';
const template_list = `
╔═══『 *DAFTAR LIST* 』
╠
{LIST_ITEMS}
╚═══════════════════

_ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ɪꜱɪ ʟɪꜱᴛ ᴋᴇᴛɪᴋ *ᴛᴇᴋꜱ* ᴅɪ ᴀᴛᴀꜱ_`;



module.exports = {
    awalanItem,
    template_list
};
